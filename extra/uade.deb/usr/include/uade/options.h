#ifndef _UADE_OPTIONS_H_
#define _UADE_OPTIONS_H_
#define UADE_CONFIG_USER_MODE (0)
#define UADE_CONFIG_BASE_DIR "/usr/share/uade"
#define UADE_CONFIG_UADE_CORE "/usr/lib/uade/uadecore"
#define UADE_CONFIG_HAVE_URANDOM
#define UADE_VERSION "2.13"
#endif /* _UADE_OPTIONS_H_ */
